# Live OCR Web App with IP Camera Streaming

This project is a Flask-based web application that captures video frames from an IP camera, processes them using OpenCV, and extracts text using Tesseract OCR. The extracted text is displayed on a web interface.

## Features
- Live video streaming from an IP camera
- Real-time OCR text extraction
- Adaptive image preprocessing for better small-text detection
- Confidence filtering to improve OCR accuracy

## Requirements
Ensure you have the following installed on your Windows system:
- Python 3.x
- pip (Python package manager)
- OpenCV
- Tesseract-OCR

## Installation

### 1. Install Dependencies
First, clone the repository and install the required Python packages:
```sh
git clone https://github.com/your-repo.git
cd your-repo
pip install -r requirements.txt
