import requests
import cv2
import numpy as np
from flask import Flask, render_template, Response, jsonify
import pytesseract

app = Flask(__name__)

# Your camera stream URL
IP_CAMERA_URL = "http://192.168.31.32:8080/video"  # Replace with your actual camera URL

# Function to generate MJPEG frames from the camera stream
def generate_frames():
    # Open the MJPEG stream
    stream = requests.get(IP_CAMERA_URL, stream=True)

    # Check for successful connection
    if stream.status_code != 200:
        print("Failed to connect to the camera stream")
        return

    bytes_data = b''
    for chunk in stream.iter_content(chunk_size=1024):
        bytes_data += chunk
        a = bytes_data.find(b'\xff\xd8')  # JPEG start byte
        b = bytes_data.find(b'\xff\xd9')  # JPEG end byte
        
        if a != -1 and b != -1:
            jpg_data = bytes_data[a:b+2]
            bytes_data = bytes_data[b+2:]

            # Attempt to decode the JPEG frame
            try:
                frame = cv2.imdecode(np.frombuffer(jpg_data, dtype=np.uint8), cv2.IMREAD_COLOR)
                if frame is not None:
                    # Resize to 600x800
                    frame = cv2.resize(frame, (800, 600))

                    # Preprocess the image (convert to grayscale, threshold)
                    processed_frame = preprocess_image(frame)

                    # Convert the processed frame to JPEG format
                    ret, buffer = cv2.imencode('.jpg', processed_frame)
                    frame_bytes = buffer.tobytes()

                    # Yield the frame for MJPEG streaming
                    yield (b'--frame\r\n' b'Content-Type: image/jpeg\r\n\r\n' + frame_bytes + b'\r\n')
            except Exception as e:
                print(f"Error decoding JPEG: {e}")
                continue  # Skip this frame and continue to the next one

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/video_feed')
def video_feed():
    return Response(generate_frames(), mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/capture', methods=['POST'])
def capture():
    # Retrieve frame for processing
    stream = requests.get(IP_CAMERA_URL, stream=True)
    bytes_data = b''
    
    # Capture the first frame
    for chunk in stream.iter_content(chunk_size=1024):
        bytes_data += chunk
        a = bytes_data.find(b'\xff\xd8')
        b = bytes_data.find(b'\xff\xd9')
        
        if a != -1 and b != -1:
            jpg_data = bytes_data[a:b+2]
            bytes_data = bytes_data[b+2:]
            try:
                frame = cv2.imdecode(np.frombuffer(jpg_data, dtype=np.uint8), cv2.IMREAD_COLOR)
                if frame is not None:
                    # Resize to 600x800
                    # frame = cv2.resize(frame, (720, 480))
                    frame = cv2.resize(frame, (1600, 1200))  # Resize to make text larger


                    # Process the frame (e.g., OCR)
                    text, confidence = process_frame(frame)
                    return jsonify({'text': text, 'confidence': confidence})  # Return both text and confidence as JSON response
            except Exception as e:
                print(f"Error decoding JPEG: {e}")
                return jsonify({'text': "Error capturing image", 'confidence': None})
    
    return jsonify({'text': "Error capturing image", 'confidence': None})

def preprocess_image(frame):
    """
    Preprocess the image before performing OCR.
    - Convert to grayscale
    - Apply Gaussian blur
    - Apply adaptive thresholding (Optional)
    """
    # gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)  # Convert to grayscale
    # gray = cv2.GaussianBlur(gray, (11, 11), 0)  # Apply Gaussian blur
    # _, thresh = cv2.threshold(gray, 200, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)  # Threshold using OTSU
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)  # Convert to grayscale
    gray = cv2.GaussianBlur(gray, (5, 5), 0)  # Apply Gaussian blur
    gray = cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                             cv2.THRESH_BINARY, 11, 11)  # Adaptive thresholding
    _, thresh = cv2.threshold(gray, 150, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)  # Threshold using OTSU


    return thresh  # Return the thresholded image

def process_frame(frame):
    """
    Process the captured frame and extract text using OCR.
    """
    gray = preprocess_image(frame)

    # Use Tesseract to perform OCR on the thresholded image with data output for confidence
    config = "--oem 3 --psm 6"  # OCR configuration (PSM 6 for block text)
    results = pytesseract.image_to_data(gray, config=config, output_type=pytesseract.Output.DICT)

    # Extract text and confidence
    text = []
    confidence = []
    
    for i in range(len(results['text'])):
        if results['text'][i].strip():  # Only consider non-empty text
            text.append(results['text'][i])
            confidence.append(int(results['conf'][i]))

    # Return text and average confidence
    avg_confidence = sum(confidence) / len(confidence) if confidence else 0
    return " ".join(text), avg_confidence  # Return both text and average confidence

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
